# LedgerLoom check

- Project: **Workbook Ch03 Adjusting Entries**
- Period: **2026-01**

## Inputs

- Inputs directory: `inputs/2026-01`
- `adjustments.csv`
- `transactions.csv`

## Summary

- Staged entries: **0**
- Errors: **0**
- Warnings: **0**
- Unmapped (suspense): **0** (see `unmapped.csv`)

## Files written

- `checks.md` – this report
- `staging.csv` – normalized staging table
- `staging_issues.csv` – row-level issues (includes original row numbers)

**Note:** `source_row_number` is 1-based relative to the first data row in the source CSV (header excluded).
